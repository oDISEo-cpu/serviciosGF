exports.handler = async (event, context) => {
  console.log('🔵 Iniciando services check...');
  
  try {
    const params = new URLSearchParams({
      key: 'IZQ-MNQ-61K-6SD-FFQ-BQG-5UP-XU9',
      username: 'Esojlin',
      action: 'services'
    });

    const endpoints = [
      'https://jonartgsm.com/webservice.php',
      'https://jonartgsm.com/api.php',
      'https://jonartgsm.com/includes/api.php',
      'https://jonartgsm.com/api/webservice.php'
    ];

    let lastError = null;
    
    for (const endpoint of endpoints) {
      console.log(`📤 Probando endpoint: ${endpoint}`);
      
      try {
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'en-US,en;q=0.9',
          },
          body: params.toString()
        });

        console.log(`📥 Response status: ${response.status}`);
        
        const text = await response.text();
        console.log(`📄 Response (primeros 300 chars): ${text.substring(0, 300)}`);
        
        if (text.trim().startsWith('<!DOCTYPE') || text.trim().startsWith('<html')) {
          console.log('⚠️ Respuesta HTML, probando siguiente endpoint...');
          continue;
        }
        
        if (response.status === 403) {
          console.log('⚠️ 403 Forbidden, probando siguiente endpoint...');
          continue;
        }
        
        try {
          const result = JSON.parse(text);
          console.log('✅ Respuesta JSON válida:', result);
          
          return {
            statusCode: 200,
            body: JSON.stringify(result)
          };
        } catch (e) {
          console.error('❌ No es JSON válido');
          lastError = { endpoint, error: 'Invalid JSON', raw: text.substring(0, 200) };
          continue;
        }
        
      } catch (err) {
        console.error(`❌ Error en ${endpoint}:`, err.message);
        lastError = { endpoint, error: err.message };
        continue;
      }
    }
    
    return {
      statusCode: 500,
      body: JSON.stringify({ 
        error: 'Ningún endpoint funcionó',
        lastError: lastError,
        endpointsTried: endpoints
      })
    };
    
  } catch (error) {
    console.error('❌ Error general:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};