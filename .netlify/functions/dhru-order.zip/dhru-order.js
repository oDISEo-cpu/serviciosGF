exports.handler = async (event, context) => {
  console.log('🔵 Iniciando order...');
  
  try {
    const { imei, serviceId } = JSON.parse(event.body);
    
    const params = new URLSearchParams({
      key: 'IZQ-MNQ-61K-6SD-FFQ-BQG-5UP-XU9',
      username: 'Esojlin',
      action: 'order',
      imei: imei,
      service: serviceId
    });

    console.log('📤 Enviando request a DHru...');
    
    const response = await fetch('https://jonartgsm.com', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params.toString()
    });

    console.log('📥 Response status:', response.status);
    
    const text = await response.text();
    console.log('📄 Response text:', text);
    
    let result;
    try {
      result = JSON.parse(text);
    } catch (e) {
      console.error('❌ Error parsing JSON:', e);
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Invalid JSON response', raw: text })
      };
    }
    
    console.log('✅ Order response:', result);
    
    return {
      statusCode: 200,
      body: JSON.stringify(result)
    };
  } catch (error) {
    console.error('❌ Error en dhru-order:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message })
    };
  }
};